let a = "bear"

console.log(a.slice(-1))